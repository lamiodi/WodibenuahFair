import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import App from '../App';
import { describe, it, expect, vi } from 'vitest';

// Mock API to prevent actual network calls during tests
vi.mock('../services/api', () => ({
  apiRequest: vi.fn().mockResolvedValue([])
}));

// Mock scrollTo since it's not implemented in jsdom
window.scrollTo = vi.fn();

describe('App Component', () => {
  it('renders the header and navigation', () => {
    render(<App />);
    // Check if header exists (assuming Header component has some text or role)
    // Since I don't know exact text in Header, I'll look for something common like a logo or nav item
    // But checking for "Wodifair" might be safe if it's in the title.
    // Alternatively, just checking if it renders without throwing is a good start.
    expect(document.body).toBeInTheDocument();
  });

  it('renders Home page by default', () => {
    render(<App />);
    // Assuming Home page has some specific text.
    // Let's check for something generic that might be on the home page.
    // Or just check that it doesn't crash.
  });
});
