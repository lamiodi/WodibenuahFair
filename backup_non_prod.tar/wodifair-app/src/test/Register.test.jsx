import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import Register from '../pages/Register';
import * as api from '../services/api';

// Mock dependencies
vi.mock('../services/api', () => ({
  apiRequest: vi.fn()
}));

vi.mock('react-hot-toast', () => ({
  default: {
    success: vi.fn(),
    error: vi.fn(),
    loading: vi.fn(),
    dismiss: vi.fn()
  }
}));

vi.mock('@paystack/inline-js', () => {
  return {
    default: class {
      newTransaction() {}
    }
  };
});

describe('Register Component', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('renders registration form', async () => {
    // Mock successful events fetch
    api.apiRequest.mockResolvedValue([
      { id: 1, title: 'Abuja Fair', location: 'Abuja' }
    ]);

    render(
      <MemoryRouter>
        <Register />
      </MemoryRouter>
    );

    // Check for form inputs
    expect(screen.getByPlaceholderText(/ENTER YOUR FULL NAME/i)).toBeInTheDocument();
    expect(screen.getByPlaceholderText(/EMAIL@ADDRESS.COM/i)).toBeInTheDocument();
    // For phone numbers, we have two inputs with same placeholder "+234..."
    // We can use getAllByPlaceholderText
    expect(screen.getAllByPlaceholderText(/\+234/i)).toHaveLength(2);
    
    // Wait for events to load (if async)
    await waitFor(() => {
      expect(api.apiRequest).toHaveBeenCalledWith('/events');
    });
  });

  it('updates form fields on input', async () => {
    api.apiRequest.mockResolvedValue([]);

    render(
      <MemoryRouter>
        <Register />
      </MemoryRouter>
    );

    const nameInput = screen.getByPlaceholderText(/ENTER YOUR FULL NAME/i);
    fireEvent.change(nameInput, { target: { value: 'Jane Doe' } });

    expect(nameInput.value).toBe('Jane Doe');
  });
});
