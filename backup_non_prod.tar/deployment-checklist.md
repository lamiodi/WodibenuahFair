# Deployment Checklist & Rollback Procedures

## Pre-Deployment
- [ ] **Security Scan**: Run `npm audit` in both `wodifair-app` and `wodifair-backend`. Fix all high/critical issues.
- [ ] **Environment Variables**:
  - [ ] Verify `DATABASE_URL` is set to production DB.
  - [ ] Verify `JWT_SECRET` is strong and rotated.
  - [ ] Verify `PAYSTACK_SECRET_KEY` and `RESEND_API_KEY` are live credentials.
  - [ ] Set `NODE_ENV=production`.
- [ ] **Database**:
  - [ ] Backup existing production database.
  - [ ] Run migration scripts (if any) to match `schema.sql`.
- [ ] **Build**:
  - [ ] Frontend: Run `npm run build` and ensure `dist/` folder is generated without errors.
  - [ ] Backend: Ensure tests pass (`npm test`).

## Deployment Steps
### Backend
1.  SSH into server or push to PaaS (Render/Heroku).
2.  Install production dependencies: `npm install --production`.
3.  Start process: `node server.js` (or use PM2: `pm2 start server.js`).
4.  Verify health check: `curl http://localhost:5000/`.

### Frontend
1.  Deploy `dist/` folder to static host (Vercel/Netlify/S3).
2.  Verify routing works (refresh on a non-root route to check SPA fallback).

## Post-Deployment Verification
- [ ] **Smoke Test**: Load homepage.
- [ ] **Critical Path**: Register a test vendor account.
- [ ] **Payment**: Verify mock payment flow (if test mode) or check Paystack integration.
- [ ] **Logs**: Check backend logs for startup errors.

## Rollback Procedures
If a critical failure occurs:

### Frontend Rollback
1.  **Vercel/Netlify**: Revert to previous deployment via dashboard "Instant Rollback".
2.  **Manual**: Re-upload the previous build artifact from backup.

### Backend Rollback
1.  **Code**: Revert git commit: `git revert HEAD` and re-deploy.
2.  **Database**:
    - If schema changed and broke data: Restore from pre-deployment backup.
    - Command: `psql -U user -d dbname < backup.sql`.
